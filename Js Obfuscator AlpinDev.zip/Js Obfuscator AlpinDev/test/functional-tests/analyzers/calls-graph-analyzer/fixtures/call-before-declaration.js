bar();

function bar () {

}
